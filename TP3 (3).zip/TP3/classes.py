#File of all class objects/sprites in game
import module_manager
module_manager.review()
import pygame
from TP3 import *

class Button1(pygame.sprite.Sprite):
    def __init__(self, path, x, y, width, height):
        super(Button1, self).__init__()
        (self.x, self.y) = (x, y)
        (self.width, self.height) = (width, height)
        self.image = pygame.image.load(path)
        self.image = self.image.convert_alpha()
        self.rect = pygame.Rect(self.x, self.y, self.width, self.height)

class BeatCircle(pygame.sprite.Sprite):
    white=(255, 255, 255)
    def __init__(self, x, y, color, number):
        super(BeatCircle, self).__init__()
        self.x=x
        self.y=y
        self.color=color
        self.number=number
        self.radius=50
        self.border=4
        self.clock=0.1
        self.outerRadius=self.radius*4
        self.ring=self.outerRadius
        self.outerWidth=3
        self.shrinkSize=(self.outerRadius//60)-(self.radius//60)
        self.rect=pygame.Rect(self.x - self.outerRadius, self.y - self.outerRadius,
                                2 * self.outerRadius, 2 * self.outerRadius)
        self.image=pygame.Surface((2 * self.outerRadius, 2 * self.outerRadius),
                                    pygame.SRCALPHA|pygame.HWSURFACE)
        self.outline=4
        self.fontSize=50
        self.missTime=0.2
        self.missClock=None
        self.draw()

    def shrinkRing(self, sec):
        self.clock+=sec
        if self.missClock!=None: #calculating 
            self.missClock-=sec #when ring should disappear
            if self.missClock<=0:
                print(self.missClock)
                self.kill()
        if self.ring>self.radius:
            self.ring-=self.shrinkSize
        self.draw()

    def draw(self): #draws the beats
        self.image.fill((255,255, 255,0))
        pygame.draw.circle(self.image, BeatCircle.white, (self.outerRadius, self.outerRadius), self.ring, self.outerWidth)
        radius=2*self.radius
        outline=2*self.outline
        newWindow=pygame.Surface((2*radius, 2*radius), pygame.SRCALPHA|pygame.HWSURFACE)
        pygame.draw.circle(newWindow, BeatCircle.white, (radius, radius), radius)
        pygame.draw.circle(newWindow, self.color, (radius, radius), radius-outline)
        width=radius
        height=radius
        newWindow=pygame.transform.smoothscale(newWindow, (width, height))
        start=self.outerRadius-self.radius
        self.image.blit(newWindow, (start, start))
        self.drawText() #draws the numbers
        if self.missClock!=None: #beats fade for smoother gameplay
            #pygame example https://stackoverflow.com/questions/15177568/pygame-surface-fade-in-out
            a=max(int((self.missClock/self.missTime)*255), 0)
            a=max(a, 0)
            fillSpace=(start, start, width, height)
            self.image.fill((255,255,255, a), fillSpace, pygame.BLEND_RGBA_MIN)

    def drawText(self): #draws number on beats
        font=pygame.font.SysFont("Arial", self.fontSize)
        text=font.render(str(self.number), 1, (255, 255, 255))
        position=text.get_rect()
        position.centerx=self.image.get_rect().centerx
        position.centery=self.image.get_rect().centery
        self.image.blit(text, position)

    def getPosition(self):
        return self.x, self.y

    def draining(self): #calculates when beats should disappear
        self.missClock=self.missTime


class MouseLocation(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super(MouseLocation, self).__init__()
        self.radius=1
        self.x=x
        self.y=y
        self.rect=pygame.Rect(self.x-self.radius, self.y-self.radius, 2*self.radius, 2*self.radius)

class FadingText(pygame.sprite.Sprite):
    white=(255, 255, 255)
    font="Tahoma"
    def __init__(self, window, text, size, x, y, anchor="nw", color=white, font=font):
        super(FadingText, self).__init__()
        self.x=x
        self.y=y
        self.text=text
        self.anchor=anchor
        self.color=color
        self.window=window
        self.time=0
        self.font=pygame.font.SysFont(font, size)
        self.width, self.height=self.font.size(self.text)
        self.initPosition()
        self.rect=pygame.Rect(self.areaX, self.areaY, self.width, self.height)
        self.image=pygame.Surface((self.width, self.height), pygame.SRCALPHA|pygame.HWSURFACE)
        self.image=self.image.convert_alpha()
        self.missTime=0.2
        self.missClock=None
        self.draw()
        self.window.blit(self.image, (self.areaX, self.areaY))

    def initPosition(self):
        if self.anchor=="nw":
            self.areaX=self.x
            self.areaY=self.y
        if self.anchor=="ne":
            self.areaX=self.x-self.width
            self.areaY=self.y
        if self.anchor=="sw":
            self.areaX=self.x
            self.areaY=self.y-self.height
        if self.anchor=="se":
            self.areaX=self.x-self.width
            self.areaY=self.y-self.height
        if self.anchor=="center":
            self.areaX=self.x-self.width//2
            self.areaY=self.y-self.height//2

    def draw(self):
        text=self.font.render(self.text, 1, self.color)
        self.image.blit(text, (0, 0))
        if self.missClock!=None: #text fades out smoother
            a=int((self.missClock/self.missTime)*255)
            a=max(a, 0)
            self.image.set_alpha(a)



    def update(self, sec=0):
        self.time+=sec
        if self.missClock!=None:
            self.missClock-=sec
            if self.missClock<=0:
                self.kill() #calculates when to kill text
        self.draw()
        self.window.blit(self.image, (self.areaX, self.areaY))

    def draining(self):
        self.missClock=self.missTime

class PermText(FadingText):
    gray=(102,102,102,0)
    bg=(255,182,193)
    font="Tahoma"
    def __init__(self, window, text, size, x, y, anchor="nw"):
        super().__init__(window, text, size, x, y, anchor)

    def draw(self):
        super().draw()
        text=self.font.render(self.text, 1, PermText.gray)
        self.image.blit(text, (0,0))

class HealthBar(pygame.sprite.Sprite):
    def __init__(self, surface, x, y, width, height):
        super(HealthBar, self).__init__()
        #self.rect=pygame.Rect(100, 100, 700, 100)
        self.image=pygame.Surface((700, 100), pygame.SRCALPHA|pygame.HWSURFACE)
        self.surface=surface
        self.fill=1000
        self.x=x
        self.y=y
        self.width=width
        self.height=height
        self.game=BlitzBeatGame()
        self.draw()

    def draw(self):
        self.image.fill((60, 79, 113))
        pygame.draw.rect(self.surface, (102, 102, 102), (50, 100, 1000, 50), 0)
        pygame.draw.rect(self.surface, (50,205,50), (50, 100, self.fill, 50), 0)

    def update(self):
        if self.fill>0:
            self.fill-=1

    def missUpdate(self):
        if self.fill>0:
            self.fill-=5

    def hitUpdate(self):
        if self.fill<900:
            self.fill+=100



